# PROMPT: Setup Inicial de Nordia POS

## Objetivo
Preparar el ambiente de desarrollo con todas las dependencias necesarias.

## Ejecutar estos comandos:

### 1. Crear estructura base
```bash
cd ~/MVPs/nordia-pos
mkdir -p {backend,frontend,database,docker,docs,scripts}

# Crear archivos de configuración
touch .env .gitignore README.md
```

### 2. Configurar Backend (Python/FastAPI)
```bash
cd backend

# Crear ambiente virtual
python3 -m venv venv
source venv/bin/activate

# Instalar dependencias
pip install fastapi==0.104.1 \
           uvicorn==0.24.0 \
           sqlalchemy==2.0.23 \
           psycopg2-binary==2.9.9 \
           mercadopago==2.2.1 \
           python-jose[cryptography]==3.3.0 \
           passlib[bcrypt]==1.7.4 \
           redis==5.0.1 \
           celery==5.3.4 \
           httpx==0.25.2 \
           pytest==7.4.3

# Guardar dependencias
pip freeze > requirements.txt
```

### 3. Configurar Frontend (Next.js)
```bash
cd ../frontend

# Crear proyecto Next.js
npx create-next-app@latest . \
    --typescript \
    --tailwind \
    --app \
    --no-eslint \
    --import-alias "@/*"

# Instalar dependencias adicionales
npm install axios \
           zustand \
           @tanstack/react-query \
           mercadopago \
           @zxing/library \
           react-hot-toast \
           lucide-react

# Instalar dependencias de desarrollo
npm install -D @types/node
```

### 4. Crear archivo de variables de entorno
```bash
cd ~/MVPs/nordia-pos

cat > .env << 'EOF'
# API
API_PORT=8000
FRONTEND_PORT=3000

# Database
DATABASE_URL=postgresql://nordia:nordiapass@localhost:5432/nordia_pos
REDIS_URL=redis://localhost:6379

# MercadoPago (Argentina)
MERCADOPAGO_ACCESS_TOKEN=TEST-YOUR-ACCESS-TOKEN
MERCADOPAGO_PUBLIC_KEY=TEST-YOUR-PUBLIC-KEY

# Security
JWT_SECRET=your-secret-key-change-this
ENCRYPTION_KEY=your-encryption-key-change-this

# AFIP (preparado para futuro)
AFIP_CERT_PATH=./certs/afip.crt
AFIP_KEY_PATH=./certs/afip.key
AFIP_CUIT=30712345678

# Environment
NODE_ENV=development
ENVIRONMENT=development
EOF
```

### 5. Configurar .gitignore
```bash
cat > .gitignore << 'EOF'
# Dependencies
node_modules/
venv/
__pycache__/
*.pyc

# Environment
.env
.env.local
.env.*.local

# Build
dist/
build/
.next/
out/

# IDE
.vscode/
.idea/
*.swp
*.swo

# Logs
*.log
npm-debug.log*
yarn-error.log*

# OS
.DS_Store
Thumbs.db

# Testing
coverage/
.pytest_cache/

# Database
*.db
*.sqlite
EOF
```

## 🔧 Troubleshooting

### Si Python no está instalado:
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv
```

### Si Node.js no está instalado:
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install nodejs
```

### Si PostgreSQL no está instalado:
```bash
sudo apt install postgresql postgresql-contrib
sudo -u postgres createdb nordia_pos
sudo -u postgres createuser nordia -P  # Password: nordiapass
```

## ✅ Verificación

El setup está completo cuando:
- `backend/venv` existe y está activado
- `frontend/node_modules` existe
- `.env` tiene todas las variables configuradas
- PostgreSQL está corriendo en puerto 5432

## ⏭️ Siguiente paso
Continuar con `02-development/backend-api.md`
