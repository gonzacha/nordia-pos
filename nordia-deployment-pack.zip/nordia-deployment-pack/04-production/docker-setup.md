# PROMPT: Docker Setup para Producción

## Configurar Docker para deploy de Nordia POS

### 1. Docker Compose Principal: `docker-compose.yml`

```yaml
version: '3.8'

services:
  # Base de Datos PostgreSQL
  db:
    image: postgres:15-alpine
    container_name: nordia-db
    environment:
      - POSTGRES_DB=nordia_pos
      - POSTGRES_USER=nordia
      - POSTGRES_PASSWORD=nordiapass2025
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./database/init.sql:/docker-entrypoint-initdb.d/init.sql
    ports:
      - "5432:5432"
    networks:
      - nordia-network
    restart: unless-stopped

  # Redis para caché y colas
  redis:
    image: redis:7-alpine
    container_name: nordia-redis
    ports:
      - "6379:6379"
    networks:
      - nordia-network
    restart: unless-stopped

  # Backend API
  backend:
    build: 
      context: ./backend
      dockerfile: Dockerfile
    container_name: nordia-backend
    environment:
      - DATABASE_URL=postgresql://nordia:nordiapass2025@db:5432/nordia_pos
      - REDIS_URL=redis://redis:6379
      - MERCADOPAGO_ACCESS_TOKEN=${MERCADOPAGO_ACCESS_TOKEN}
      - MERCADOPAGO_PUBLIC_KEY=${MERCADOPAGO_PUBLIC_KEY}
      - JWT_SECRET=${JWT_SECRET}
      - ENVIRONMENT=production
    ports:
      - "8000:8000"
    depends_on:
      - db
      - redis
    networks:
      - nordia-network
    restart: unless-stopped
    volumes:
      - ./backend:/app
    command: uvicorn main:app --host 0.0.0.0 --port 8000 --reload

  # Frontend Next.js
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: nordia-frontend
    environment:
      - NEXT_PUBLIC_API_URL=http://backend:8000
      - NODE_ENV=production
    ports:
      - "3000:3000"
    depends_on:
      - backend
    networks:
      - nordia-network
    restart: unless-stopped

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    container_name: nordia-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./nginx/ssl:/etc/nginx/ssl
    depends_on:
      - frontend
      - backend
    networks:
      - nordia-network
    restart: unless-stopped

networks:
  nordia-network:
    driver: bridge

volumes:
  postgres_data:
```

### 2. Dockerfile Backend: `backend/Dockerfile`

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Instalar dependencias del sistema
RUN apt-get update && apt-get install -y \
    gcc \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# Copiar requirements
COPY requirements.txt .

# Instalar dependencias Python
RUN pip install --no-cache-dir -r requirements.txt

# Copiar código
COPY . .

# Puerto
EXPOSE 8000

# Comando de inicio
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### 3. Dockerfile Frontend: `frontend/Dockerfile`

```dockerfile
FROM node:18-alpine AS deps
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:18-alpine AS runner
WORKDIR /app

ENV NODE_ENV production
ENV NEXT_TELEMETRY_DISABLED 1

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT 3000
ENV HOSTNAME "0.0.0.0"

CMD ["node", "server.js"]
```

### 4. Configuración Nginx: `nginx/nginx.conf`

```nginx
events {
    worker_connections 1024;
}

http {
    upstream backend {
        server backend:8000;
    }

    upstream frontend {
        server frontend:3000;
    }

    server {
        listen 80;
        server_name pos.nordia.com localhost;

        # API Backend
        location /api {
            proxy_pass http://backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # Docs de la API
        location /docs {
            proxy_pass http://backend/docs;
            proxy_set_header Host $host;
        }

        # Frontend
        location / {
            proxy_pass http://frontend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_cache_bypass $http_upgrade;
        }
    }
}
```

### 5. Script de inicialización DB: `database/init.sql`

```sql
-- Crear tablas para Nordia POS

CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INTEGER DEFAULT 0,
    barcode VARCHAR(50),
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales (
    id SERIAL PRIMARY KEY,
    total DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50),
    customer_email VARCHAR(255),
    status VARCHAR(50) DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sale_items (
    id SERIAL PRIMARY KEY,
    sale_id INTEGER REFERENCES sales(id),
    product_id INTEGER REFERENCES products(id),
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL
);

-- Insertar productos de ejemplo
INSERT INTO products (name, price, stock, barcode, category) VALUES
    ('Café', 850.00, 100, '7798123456789', 'Bebidas'),
    ('Medialunas', 450.00, 50, '7798123456790', 'Panadería'),
    ('Tostado', 1200.00, 30, '7798123456791', 'Sandwiches'),
    ('Jugo Natural', 600.00, 45, '7798123456792', 'Bebidas'),
    ('Ensalada', 1500.00, 20, '7798123456793', 'Comidas');
```

## Comandos de ejecución:

### Desarrollo local:
```bash
# Levantar todo
docker-compose up -d

# Ver logs
docker-compose logs -f

# Detener todo
docker-compose down

# Limpiar todo (incluyendo volúmenes)
docker-compose down -v
```

### Producción:
```bash
# Build de imágenes
docker-compose build

# Deploy en producción
docker-compose up -d --build

# Verificar estado
docker-compose ps

# Ver logs de un servicio específico
docker-compose logs -f backend
```

## Verificación:

Después de ejecutar `docker-compose up -d`, verificar:

1. **Frontend**: http://localhost:3000
2. **API Docs**: http://localhost:8000/docs
3. **PostgreSQL**: puerto 5432
4. **Redis**: puerto 6379

## Variables de entorno para producción:

Crear archivo `.env.production`:
```env
MERCADOPAGO_ACCESS_TOKEN=APP_USR-real-token-here
MERCADOPAGO_PUBLIC_KEY=APP_USR-real-public-key
JWT_SECRET=super-secret-key-change-this
DATABASE_URL=postgresql://nordia:nordiapass2025@db:5432/nordia_pos
REDIS_URL=redis://redis:6379
```

## Troubleshooting:

### Si el frontend no conecta con el backend:
```javascript
// En frontend, cambiar NEXT_PUBLIC_API_URL
NEXT_PUBLIC_API_URL=http://localhost:8000
```

### Si la DB no inicia:
```bash
# Verificar logs de postgres
docker-compose logs db

# Reiniciar solo la DB
docker-compose restart db
```

### Si hay problemas de permisos:
```bash
# Dar permisos a los volúmenes
sudo chown -R $USER:$USER .
```

## Siguiente paso
Continuar con `05-deployment/vps-setup.md`
