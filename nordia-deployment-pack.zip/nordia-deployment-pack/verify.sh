#!/bin/bash
# verify.sh - Verificar integridad del deployment pack

echo "🔍 Verificando integridad del Nordia Deployment Pack..."

if [ ! -f "checksums.txt" ]; then
    echo "❌ Archivo checksums.txt no encontrado"
    exit 1
fi

if sha256sum -c checksums.txt --quiet; then
    echo "✅ Todos los archivos verificados correctamente"
    echo "📦 Pack listo para usar"
    echo ""
    echo "Próximo paso:"
    echo "1. Lee MASTER-PROMPT.md"
    echo "2. Sigue las instrucciones paso a paso"
    echo "3. ¡Tendrás tu POS funcionando en 2 horas!"
else
    echo "❌ Algunos archivos no coinciden con los checksums"
    exit 1
fi
