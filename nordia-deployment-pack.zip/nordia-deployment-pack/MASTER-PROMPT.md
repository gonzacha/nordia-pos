# 🚀 NORDIA POS - MASTER DEPLOYMENT PROMPT

## Instrucciones para Claude Code / ChatGPT

Necesito tu ayuda para hacer el deploy completo de **Nordia POS**, un sistema de punto de venta que será la base de la primera Super App de Latinoamérica.

## 🎯 Objetivo

Crear y deployar un POS funcional con:
- Backend API (FastAPI)
- Frontend táctil (React/Next.js)
- Integración MercadoPago (Argentina)
- Base de datos PostgreSQL
- Docker para producción
- Deploy en VPS con SSL

## 📋 Plan de Ejecución (2 horas total)

### FASE 1: Setup Inicial (15 minutos)
```bash
# Crear estructura del proyecto
cd ~/MVPs/nordia-pos
mkdir -p {backend,frontend,database,docker,docs,scripts}

# Backend setup
cd backend
python3 -m venv venv
source venv/bin/activate
pip install fastapi uvicorn sqlalchemy psycopg2-binary mercadopago python-jose passlib redis celery pytest

# Frontend setup  
cd ../frontend
npx create-next-app@latest . --typescript --tailwind --app --no-eslint
npm install axios zustand react-query mercadopago @zxing/library
```

### FASE 2: Backend API (20 minutos)

Crear el archivo `backend/main.py` con el código del backend (ver archivo `02-development/backend-api.md`)

### FASE 3: Frontend POS (20 minutos)

Crear el componente POS en `frontend/app/page.tsx` (ver archivo `02-development/frontend-pos.md`)

### FASE 4: Base de Datos (10 minutos)

Crear schema PostgreSQL (ver archivo `02-development/database-schema.md`)

### FASE 5: Docker Setup (15 minutos)

Configurar Docker Compose (ver archivo `04-production/docker-setup.md`)

### FASE 6: Testing (15 minutos)

Ejecutar tests básicos (ver archivo `03-testing/integration-tests.md`)

### FASE 7: Deploy a VPS (25 minutos)

Deploy en DigitalOcean/Linode (ver archivo `05-deployment/vps-setup.md`)

## 🚨 Si algo falla

En cada paso, si encuentras un error:
1. Primero intenta la alternativa sugerida en el archivo correspondiente
2. Si persiste, simplifica el componente (quitar features no críticas)
3. Como último recurso, salta al siguiente paso y documenta el issue

## 🎯 Criterio de Éxito

El proyecto está listo cuando:
- [ ] El POS se ve en http://localhost:3000
- [ ] La API responde en http://localhost:8000/docs
- [ ] Se puede crear una venta de prueba
- [ ] Docker Compose levanta todos los servicios
- [ ] El código está subido a GitHub

## 🇦🇷 Configuración Argentina

Asegurate de:
- Configurar MercadoPago con tokens de Argentina
- Usar ARS como moneda por defecto
- Preparar estructura para AFIP (aunque no esté activa)
- Timezone: America/Argentina/Buenos_Aires

## 💡 Notas Importantes

1. **Prioridad**: Funcionalidad > Perfección
2. **Objetivo**: Tener algo DEMOSTRABLE hoy
3. **Foco**: POS básico que procese ventas
4. **No necesario ahora**: Autenticación compleja, reportes, multi-sucursal

## ▶️ EMPEZAR

Comienza con la FASE 1 y avanza secuencialmente. 
Cada fase tiene su archivo detallado en las carpetas correspondientes.

¡Vamos a construir la primera Super App de LATAM!

---

**Tiempo estimado total**: 2 horas
**Dificultad**: Media
**Resultado**: POS funcional listo para producción
