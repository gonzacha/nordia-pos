# PROMPT: Deploy a VPS (DigitalOcean/Linode/AWS)

## Deploy completo de Nordia POS en un VPS Ubuntu

### Prerrequisitos

- VPS con Ubuntu 22.04 o 24.04
- Mínimo 2GB RAM, 2 CPUs
- Dominio apuntando al IP del VPS
- Acceso SSH como root

### PASO 1: Conectar al VPS

```bash
# Conectar por SSH
ssh root@tu-vps-ip

# Actualizar sistema
apt update && apt upgrade -y
```

### PASO 2: Instalar Docker y Docker Compose

```bash
# Instalar Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Instalar Docker Compose
apt install docker-compose-plugin -y

# Verificar instalación
docker --version
docker compose version

# Iniciar Docker
systemctl start docker
systemctl enable docker
```

### PASO 3: Configurar Firewall

```bash
# Instalar ufw
apt install ufw -y

# Configurar reglas
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw allow 3000/tcp  # Frontend (temporal)
ufw allow 8000/tcp  # Backend (temporal)

# Activar firewall
ufw --force enable
ufw status
```

### PASO 4: Clonar el Proyecto

```bash
# Instalar git
apt install git -y

# Crear directorio de aplicaciones
mkdir -p /var/www
cd /var/www

# Clonar tu repositorio (reemplazar con tu URL)
git clone https://github.com/tu-usuario/nordia-pos.git
cd nordia-pos

# O si no tienes repo, crear estructura
mkdir -p nordia-pos/{backend,frontend,database,nginx}
cd nordia-pos
```

### PASO 5: Configurar Variables de Entorno

```bash
# Crear archivo .env para producción
cat > .env << 'EOF'
# Database
POSTGRES_DB=nordia_pos
POSTGRES_USER=nordia
POSTGRES_PASSWORD=super_secure_password_change_this

# Backend
DATABASE_URL=postgresql://nordia:super_secure_password_change_this@db:5432/nordia_pos
REDIS_URL=redis://redis:6379
JWT_SECRET=your-super-secret-jwt-key-change-this
ENVIRONMENT=production

# MercadoPago Production (Argentina)
MERCADOPAGO_ACCESS_TOKEN=APP_USR-your-real-access-token
MERCADOPAGO_PUBLIC_KEY=APP_USR-your-real-public-key

# Frontend
NEXT_PUBLIC_API_URL=https://api.pos.nordia.com
NODE_ENV=production
EOF

# Proteger el archivo
chmod 600 .env
```

### PASO 6: Subir Archivos del Proyecto

Si no clonaste desde Git, sube los archivos:

```bash
# Desde tu máquina local
scp -r ~/MVPs/nordia-pos/* root@tu-vps-ip:/var/www/nordia-pos/

# O usar rsync para actualización incremental
rsync -avz --exclude 'node_modules' --exclude 'venv' \
  ~/MVPs/nordia-pos/ root@tu-vps-ip:/var/www/nordia-pos/
```

### PASO 7: Construir y Lanzar con Docker

```bash
cd /var/www/nordia-pos

# Construir imágenes
docker compose build

# Lanzar servicios
docker compose up -d

# Ver logs
docker compose logs -f

# Verificar que todo esté corriendo
docker compose ps
```

### PASO 8: Configurar Dominio y SSL con Certbot

```bash
# Instalar Certbot y Nginx
apt install certbot python3-certbot-nginx nginx -y

# Detener nginx si está corriendo
systemctl stop nginx

# Configurar Nginx para tu dominio
cat > /etc/nginx/sites-available/nordia-pos << 'EOF'
server {
    listen 80;
    server_name pos.nordia.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /docs {
        proxy_pass http://localhost:8000/docs;
        proxy_set_header Host $host;
    }
}
EOF

# Activar el sitio
ln -s /etc/nginx/sites-available/nordia-pos /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default

# Verificar configuración
nginx -t

# Iniciar Nginx
systemctl start nginx
systemctl enable nginx

# Obtener certificado SSL
certbot --nginx -d pos.nordia.com --non-interactive --agree-tos -m admin@nordia.com

# Configurar renovación automática
echo "0 0 * * * root certbot renew --quiet" >> /etc/crontab
```

### PASO 9: Configurar Backups Automáticos

```bash
# Crear script de backup
cat > /root/backup-nordia.sh << 'EOF'
#!/bin/bash
# Backup de base de datos Nordia POS

BACKUP_DIR="/root/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_CONTAINER="nordia-db"

mkdir -p $BACKUP_DIR

# Backup de PostgreSQL
docker exec $DB_CONTAINER pg_dump -U nordia nordia_pos > $BACKUP_DIR/nordia_db_$DATE.sql

# Comprimir
gzip $BACKUP_DIR/nordia_db_$DATE.sql

# Eliminar backups antiguos (más de 7 días)
find $BACKUP_DIR -name "*.sql.gz" -mtime +7 -delete

echo "Backup completado: nordia_db_$DATE.sql.gz"
EOF

chmod +x /root/backup-nordia.sh

# Agregar a cron (backup diario a las 2 AM)
echo "0 2 * * * /root/backup-nordia.sh" >> /etc/crontab
```

### PASO 10: Monitoreo y Mantenimiento

```bash
# Instalar herramientas de monitoreo
apt install htop netdata -y

# Ver uso de recursos
htop

# Ver logs de Docker
docker compose logs -f backend
docker compose logs -f frontend

# Reiniciar servicios si es necesario
docker compose restart backend
docker compose restart frontend

# Actualizar aplicación
cd /var/www/nordia-pos
git pull
docker compose build
docker compose up -d
```

## Scripts Útiles

### Script de healthcheck: `healthcheck.sh`

```bash
#!/bin/bash
# Verificar que todos los servicios estén funcionando

echo "🔍 Verificando servicios de Nordia POS..."

# Backend
if curl -s http://localhost:8000/health > /dev/null; then
    echo "✅ Backend API: OK"
else
    echo "❌ Backend API: FALLA"
fi

# Frontend
if curl -s http://localhost:3000 > /dev/null; then
    echo "✅ Frontend: OK"
else
    echo "❌ Frontend: FALLA"
fi

# PostgreSQL
if docker exec nordia-db pg_isready > /dev/null 2>&1; then
    echo "✅ PostgreSQL: OK"
else
    echo "❌ PostgreSQL: FALLA"
fi

# Redis
if docker exec nordia-redis redis-cli ping > /dev/null 2>&1; then
    echo "✅ Redis: OK"
else
    echo "❌ Redis: FALLA"
fi
```

### Script de actualización: `update-nordia.sh`

```bash
#!/bin/bash
# Actualizar Nordia POS desde Git

cd /var/www/nordia-pos

echo "📦 Actualizando Nordia POS..."

# Backup antes de actualizar
/root/backup-nordia.sh

# Pull últimos cambios
git pull

# Rebuild y restart
docker compose build
docker compose up -d

echo "✅ Actualización completa"
```

## Verificación Final

Tu POS debería estar accesible en:

- **Frontend**: https://pos.nordia.com
- **API Docs**: https://pos.nordia.com/docs
- **Health**: https://pos.nordia.com/api/health

## Troubleshooting

### Si el dominio no resuelve:
```bash
# Verificar DNS
nslookup pos.nordia.com
dig pos.nordia.com
```

### Si Docker no inicia:
```bash
# Ver logs detallados
journalctl -u docker.service
docker compose logs --tail=50
```

### Si hay problemas de memoria:
```bash
# Ver uso de memoria
free -h
docker stats
```

### Si necesitas hacer rollback:
```bash
# Restaurar backup de DB
gunzip < /root/backups/nordia_db_FECHA.sql.gz | \
  docker exec -i nordia-db psql -U nordia nordia_pos
```

## 🎉 ¡LISTO!

Tu Nordia POS está ahora en producción con:
- ✅ HTTPS/SSL
- ✅ Backups automáticos
- ✅ Docker containerizado
- ✅ Nginx como reverse proxy
- ✅ Monitoreo básico

## Costos Estimados (mensual)

- DigitalOcean Droplet 2GB: $12 USD
- Linode 2GB: $12 USD
- AWS EC2 t3.small: ~$15 USD
- Dominio: $12 USD/año

**Total: ~$15 USD/mes**
